#pragma once

#include "ofMain.h"
#include "ofxGui.h"
#include "ofxCv.h"



class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
    
    bool menuToggle;
    
    ofVideoGrabber grabber;
    ofImage resultImg;
    ofParameter<float> r;
    ofParameter<float> g;
    ofParameter<float> b;
    ofParameter<int> brightness;
    
    ofParameter<ofColor> colorTarget;
    ofColor colorPicker;
    ofImage pickerImg;

    ofParameter<int> colorOffset;


    ofParameter<bool> captureBG;
    ofImage BGImg;
    
    ofxPanel guiPanel;
    
    ofxCv::ContourFinder contour;


    ofParameter<int> blurAmount;
    ofParameter<int> dilateAmount;
    ofParameter<int> erodeIterations;

		
};
