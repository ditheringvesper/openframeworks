#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    grabber.setDeviceID(1);
    grabber.setup(ofGetWidth(), ofGetHeight());
    ofSetWindowShape(ofGetWidth(), ofGetHeight());
    
    blurAmount.set("Blur Amount", 0, 0, 100);
    erodeIterations.set("Erode Iterations", 0, 0, 10);
    dilateAmount.set("Dilate Amount", 0, 0, 100);
    
    r.set("red", 2,0,255);
    g.set("green", 2,0,255);
    b.set("blue", 2,0,255);
    brightness.set("brightness", 10,0,255);
    captureBG.set("capture background", true);
    
    contour.setUseTargetColor(true);
    colorTarget.set("Color Target", ofColor(255, 0, 0));
    colorOffset.set("Color Offset", 10, 0, 255);
    
    guiPanel.setup("greasy filter");
    guiPanel.add(r);
    guiPanel.add(g);
    guiPanel.add(b);
    guiPanel.add(brightness);
    guiPanel.add(captureBG);
    
    guiPanel.add(blurAmount);
    guiPanel.add(erodeIterations);
    guiPanel.add(dilateAmount);
    
    guiPanel.add(colorTarget);
//    guiPanel.add(colorOffset);

    resultImg.allocate(grabber.getWidth(), grabber.getHeight(), OF_IMAGE_COLOR);
    
    bool menuToggle = true;

}

//--------------------------------------------------------------
void ofApp::update(){
    grabber.update();
    ofImage grabberColorImg, grabberGrayImg, grayMidImg, BWdiff,midImg;

    if (grabber.isFrameNew())
    {
        pickerImg.setFromPixels(resultImg.getPixels());

        // Update parameters.
        contour.setTargetColor(colorTarget,ofxCv::TRACK_COLOR_HSV);
        contour.setThreshold(colorOffset);
        
        // Find contours.
        contour.findContours(pickerImg);
    }
    
    grabberColorImg.setFromPixels(grabber.getPixels());

    
    ofxCv::copyGray(grabberColorImg, grabberGrayImg);
    
    if (captureBG)
    {
        BGImg=grabberColorImg;
        captureBG = false;
    }
    
    if (blurAmount > 0)
    {
      ofxCv::medianBlur(BGImg, blurAmount);
    }
    if (erodeIterations > 0)
    {
      ofxCv::erode(BGImg, erodeIterations.get());
    }
    BGImg.update();
    
    if (dilateAmount > 0)
    {
      ofxCv::dilate(grabberColorImg, dilateAmount.get());
    }
    grabberColorImg.update();
    
    ofxCv::threshold(grabberColorImg, r);
    ofxCv::threshold(grabberColorImg, g);
    ofxCv::threshold(grabberColorImg, b);
    ofxCv::threshold(grabberGrayImg, brightness);
    
    ofxCv::subtract(BGImg, grabberGrayImg, BWdiff);
    ofxCv::bitwise_and(BWdiff, grabberColorImg, midImg);
    ofxCv::bitwise_xor(BGImg, midImg, resultImg);

    
    resultImg.update();
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetColor(255);
    resultImg.draw(0,0,ofGetWidth(), ofGetHeight());

//    ofPushStyle();
//    ofSetColor(colorPicker);
//    contour.draw();
//    ofPopStyle();

    // Draw the color under the mouse.
      ofPushStyle();
      ofSetColor(colorPicker.getInverted());
      ofDrawRectangle(ofGetMouseX() - 9, ofGetMouseY() - 9, 18, 18);
      ofNoFill();
      ofSetColor(colorPicker);
      ofDrawRectangle(ofGetMouseX() - 7, ofGetMouseY() - 7, 14, 14);
      ofPopStyle();
    
    guiPanel.draw();

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if (key == ' '){
        brightness.set("brightness", ofRandom(0,255),0,255);
       }
    if (key == 'r'){
        r.set("r", ofRandom(0,255),0,255);
       }
    if (key == 'g'){
        g.set("g", ofRandom(0,255),0,255);
       }
    if (key == 'b'){
        b.set("b", ofRandom(0,255),0,255);
       }
    
    if (key == 'c'){
        captureBG =! false;
       }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    if (!guiPanel.getShape().inside(x, y))
     {
       // Track the color under the mouse.
       colorTarget = colorPicker;
         colorPicker = pickerImg.getColor(ofGetMouseX(), ofGetMouseY());
         r.set(colorPicker.r);
         g.set(colorPicker.g);
         b.set(colorPicker.b);
     }
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}



