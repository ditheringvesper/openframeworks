#pragma once

#include "ofMain.h"
#include "ofxKinect.h"
#include "ofxCv.h"
#include "ofxGui.h"



class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void mousePressed(int x, int y, int button);
	
    
    ofxKinect kinect;

    ofxPanel guiPanel;

    ofParameter<int> blurAmount;
    ofParameter<int> dilateAmount;
    ofParameter<int> colorOffset;
    ofParameter<float> focalDist;
    ofParameter<float> nearVal;
    ofParameter<int> farVal;
    
    ofImage nearImg;
    ofImage farImg;
    ofImage blurImg;
    ofColor bgCol;

    ofImage thresholdImg;

    int distAtMouse;
    int r,g,b;
    
		
};
