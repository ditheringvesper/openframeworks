#include "ofApp.h"

// click on the image to set the farthest threshold.
// nearest and farthes threshold also affect the background color.
//--------------------------------------------------------------
void ofApp::setup()
{
    ofSetWindowShape(ofGetWindowWidth(), ofGetWindowHeight());
    kinect.setRegistration(true);
    kinect.init();
    kinect.open();
    
    thresholdImg.allocate(640, 480, OF_IMAGE_GRAYSCALE);

    blurAmount.set("blur amount", 1, 0,50);
    dilateAmount.set("dilate amount", 1, 0,50);
    farVal.set("farthest value", 1, 0, 10001);
    nearVal.set("nearest value", 0.01f, 0.0f, 0.1f);
    colorOffset.set("color offset", 150, 0,255);
    
    guiPanel.setup("woodcut print effect", "settings.json");
    guiPanel.add(blurAmount);
    guiPanel.add(dilateAmount);
    guiPanel.add(nearVal);
    guiPanel.add(farVal);
    guiPanel.add(colorOffset);

    
    r = ofRandom(0,255);
    g = ofRandom(0,255);
    b = ofRandom(0,255);

}

//--------------------------------------------------------------
void ofApp::update(){
    kinect.update();
    bgCol = ofColor(r,g,b,255);

}


//--------------------------------------------------------------
void ofApp::draw(){
    ofSetColor(bgCol);
    if (kinect.isFrameNew())
      {
        kinect.getDepthTexture().draw(0, 0, 320,240);

        distAtMouse = kinect.getDistanceAt(ofGetMouseX(), ofGetMouseY());
        ofDrawBitmapStringHighlight(ofToString(distAtMouse, 3), ofGetMouseX(), ofGetMouseY());

        ofFloatPixels distancePix = kinect.getDistancePixels();
        ofFloatPixels rawDepthPix = kinect.getRawDepthPixels();
        ofPixels& thresholdPix = thresholdImg.getPixels();
          
        ofFloatPixels thresholdFar,thresholdNear,result;
        ofxCv::threshold(distancePix, thresholdFar, farVal);
        ofxCv::threshold(rawDepthPix, thresholdNear, nearVal,true);

        ofxCv::dilate(thresholdNear, dilateAmount.get());
        ofxCv::GaussianBlur(thresholdFar, blurAmount.get());

        ofxCv::bitwise_xor(thresholdFar, thresholdNear, result);

        blurImg.setFromPixels(result);
          
          r = ofMap(farVal, 0, 10001, 0, 255);
          g = ofMap(nearVal, 0.0f, 0.1f, 0, 255);
          b = colorOffset.get();
            
      }

    blurImg.draw(320,0);
    

    guiPanel.draw();
}


//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    if (true){
        farVal = distAtMouse;
    }
}

