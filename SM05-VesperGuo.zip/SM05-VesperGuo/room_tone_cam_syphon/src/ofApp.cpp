#include "ofApp.h"


/* descriptoin:
1 cam + 1 syphon client
 */

void ofApp::setup(){
    clientGrabber.setup();
    ofFboSettings settings;
    settings.width = 640;
    settings.height = 360;
    syphonFbo.allocate(settings);
    
    grabber.listDevices();
    grabber.setDeviceID(2);
    ofSetWindowShape(640*2,480);

    grabber.setup(640,480);
    grabber2.setup(640,480);

    resultImg.allocate(640,480, OF_IMAGE_COLOR);
    resultImg2.allocate(640,480, OF_IMAGE_COLOR);

    captureBackground.set("capture BG", true);
    blurVal.set("blur value", 10, 0, 50);
    colorThreshold.set("brightness threshold", 120, 0, 255);
    pixThreshRatio.set("pixel threshold ratio", 30.0f, 1.0f, 1000.0f);
//    ratioScale.set("ratio scale", 1e36, 1e35, 1e37);

    captureBackground2.set("capture BG", true);
    blurVal2.set("blur value", 10, 0, 50);
    colorThreshold2.set("brightness threshold", 120, 0, 255);
    pixThreshRatio2.set("pixel threshold ratio", 30.0f, 1.0f, 1000.0f);
    
    recStat = false;
    preStat = false;
    
    recStat2 = false;
    preStat2 = false;
    
    guiPanel.setup("room tone cam 1", "setting_syphon_cam1.json");
    guiPanel.add(recorder.setup("recorder", false));
    guiPanel.add(captureBackground);
    guiPanel.add(blurVal);
    guiPanel.add(colorThreshold);
    guiPanel.add(pixThreshRatio);
//    guiPanel.add(label.setup(recString));

    guiPanel2.setup("room tone cam 2", "setting_syphon_cam2.json");
    guiPanel2.add(captureBackground2);
    guiPanel2.add(blurVal2);
    guiPanel2.add(colorThreshold2);
    guiPanel2.add(pixThreshRatio2);

    // Set up the OSC sender.
    sendAddr = "127.0.0.1";
    sendPort = 8025;
    sender.setup(sendAddr, sendPort);
    recvPort = 8024;
    receiver.setup(recvPort);
}

//--------------------------------------------------------------
void ofApp::update(){
    grabber.update();
    grabber2.update();
    
    syphonFbo.begin();
        clientGrabber.draw(0, 0, 640,480);
    syphonFbo.end();
    syphonFbo.readToPixels(syphonPix);

// camera #1
    int counter = 0; // count the 'active' pixels in ratio to the sum pixels.
    int distanceRatio; // area ratio of the active pixels to the sum pixels.

    if (grabber.isFrameNew())
    {
        if(blurVal>0){
            ofxCv::medianBlur(grabber, blurVal.get());
        }
        // Convert the grabber image to CV space.
      grabberColorMat = ofxCv::toCv(grabber.getPixels());
      // Convert input image to grayscale.
      ofxCv::copyGray(grabberColorMat, grabberGrayMat);

      if (captureBackground)
      {
          recStat = false;
          preStat = false;
          counter = 0;

          ofxOscMessage msg;
          msg.setAddress("/stop");
          msg.addIntArg(0);
          sender.sendMessage(msg);
          cout << "0" << endl;
          
        backgroundMat = grabberGrayMat.clone();
        captureBackground =! true;
      }

      // Compute the difference image between the background and grabber.
      cv::subtract(backgroundMat, grabberGrayMat, resultMat);
      // Threshold the difference image.
      ofxCv::threshold(resultMat, colorThreshold);

      // Convert the result CV image back to OF space.
      ofxCv::toOf(resultMat, resultImg);
      // Update the image to draw it.
      resultImg.update();
    
        for (int y = 0; y < resultImg.getHeight(); y++)
          {
            for (int x = 0; x < resultImg.getWidth(); x++)
            {
              ofColor pixColor = resultImg.getColor(x, y);
              if (pixColor.getBrightness() > 250) // if pixels are 'active'
              {
                  counter++;
              }
                if (counter > resultImg.getHeight()*resultImg.getWidth() / pixThreshRatio)
                {
                    recStat = true;
//                    cout << counter << endl;
                }
                else {
                    recStat = false;
                }
            }
          }
    }
    
    
// camera #2
    int counter2 = 0;
    int distanceRatio2;
    
    if (grabber2.isFrameNew())
    {
        if(blurVal2>0){
            ofxCv::medianBlur(grabber2, blurVal2.get());
        }      grabberColorMat2 = ofxCv::toCv(syphonPix);
      ofxCv::copyGray(grabberColorMat2, grabberGrayMat2);

      if (captureBackground2)
      {
          recStat2 = false;
          preStat2 = false;
          counter2 = 0;

          ofxOscMessage msg;
          msg.setAddress("/stop");
          msg.addIntArg(0);
          sender.sendMessage(msg);
          cout << "0" << endl;

          
        backgroundMat2 = grabberGrayMat2.clone();
        captureBackground2 =! true;
      }

      cv::subtract(backgroundMat2, grabberGrayMat2, resultMat2);
      ofxCv::threshold(resultMat2, colorThreshold2);
      ofxCv::toOf(resultMat2, resultImg2);
      resultImg2.update();
    
        for (int h = 0; h < resultImg2.getHeight(); h++)
          {
            for (int w = 0; w < resultImg2.getWidth(); w++)
            {
              ofColor pixColor2 = resultImg2.getColor(w, h);
              if (pixColor2.getBrightness() > 250) // if pixels are 'active'
              {
                  counter2++;
              }
                if (counter2 > resultImg2.getHeight()*resultImg2.getWidth() / pixThreshRatio2)
                {
                    recStat2 = true;
//                    cout << counter << endl;
                }
                else {
                    recStat2 = false;
                }
            }
          }
    }
    
    
    
        
    if (recorder  == true){
        checkRecStat();
    }
    
/* cam 1 */
    if (recStat == true){
        ofxOscMessage distPan;
        distPan.setAddress("/counter");
        distPan.addIntArg(counter);
        sender.sendMessage(distPan);
    }
    
/* cam 2 */
    if (recStat2 == true){
        ofxOscMessage distPan2;
        distPan2.setAddress("/counter2");
        distPan2.addIntArg(counter2);
        sender.sendMessage(distPan2);
    }
    
    
/* indicator reset color */
    if (recStat == false && preStat == false
        && recStat2 == false && preStat2 == false)
    {
        recColor = ofColor(255,255,255);
    }

 
}

//--------------------------------------------------------------

void ofApp::draw(){
    ofBackground(recColor); // indicator of recorder status
    resultImg.draw(0, 0);
    resultImg2.draw(640, 0);

    guiPanel.draw();
    guiPanel2.draw();

}


void ofApp::checkRecStat(){
    ofxOscMessage msg;
    if (recStat == true && preStat == false
        && recStat2 == true && preStat2 == false)
    {
        msg.setAddress("/start");
        msg.addIntArg(1);
        preStat = true;
        preStat2 = true;
        recColor = ofColor(255,0,0);
        cout << "1" << endl;
    }
    if (recStat == false && preStat == false
             && recStat2 == true && preStat2 == false)
    {
        msg.setAddress("/start");
        msg.addIntArg(1);
        preStat2 = true;
        recColor = ofColor(255,0,0);
        cout << "1" << endl;
    }
    
    if (recStat == true && preStat == false
             && recStat2 == false && preStat2 == false)
    {
        msg.setAddress("/start");
        msg.addIntArg(1);
        preStat = true;
        recColor = ofColor(255,0,0);
        cout << "1" << endl;
    }
    
    if (recStat == false && preStat == true
             && recStat2 == false && preStat2 == true)
    {
        msg.setAddress("/stop");
        msg.addIntArg(0);
        preStat = false;
        preStat2 = false;
        recColor = ofColor(255,255,255);
        cout << "0" << endl;

    }
    
    if (recStat == false && preStat == true
             && recStat2 == false && preStat2 == false)
    {
        msg.setAddress("/stop");
        msg.addIntArg(0);
        preStat = false;
        recColor = ofColor(255,255,255);
        cout << "0" << endl;
    }
    
    if (recStat == false && preStat == false
             && recStat2 == false && preStat2 == true)
    {
        msg.setAddress("/stop");
        msg.addIntArg(0);
        preStat2 = false;
        recColor = ofColor(255,255,255);
        cout << "0" << endl;
    }
    
        sender.sendMessage(msg);
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

