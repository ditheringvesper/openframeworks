

- Either OF proj works as an OSC sender depends on the video-capture tool to use. They are not supposed to work together though.

- The max patch is the receiver. Its sound file path requires customization to work.







vesper guo
2022