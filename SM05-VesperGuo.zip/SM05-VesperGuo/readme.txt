

- Either OF proj works as an OSC sender depends on the video-capture tool to use. They are not supposed to work together though.

- The max patch is the receiver. Its sound file path requires customization to work.



- project development log:
https://vesperguo.notion.site/room-tone-e9c56f737e4840c2b05ad4744f42688d



vesper guo
2022