#include "ofApp.h"

/*
 Isolation: a live ⬜ cell with less than 2 live neighbors will die 😥.
 Overcrowding: a live ⬜ cell with 4 or more neighbors will die 😵.
 Reproduction: a dead ⬛ cell with exactly 3 live neighbors will live 🐣.
 */

//--------------------------------------------------------------
void ofApp::setup(){
    unicorn.allocate(ofGetWidth(), ofGetHeight(), OF_IMAGE_GRAYSCALE);
    ofSetWindowShape(unicorn.getWidth(), unicorn.getHeight());

    // generate a random b&w noise pic from a pic as the canvas
    for (int x = 0; x < unicorn.getWidth(); x++)
    {
        for (int y = 0; y < unicorn.getHeight(); y++)
        {
            if (ofRandomuf() < 0.5)
            {
                unicorn.setColor(x, y, ofColor(0));
            }
            else
            {
                unicorn.setColor(x, y, ofColor(255));
            }
        }
    }
    
    ofPixels newPix = unicorn.getPixels();
    uniPix = newPix;
    uniPixN = newPix;
    unicorn.setFromPixels(newPix);
}

//--------------------------------------------------------------
void ofApp::update(){
    
}

//--------------------------------------------------------------
void ofApp::draw(){
//    unicorn.draw(0, 0);
    
    for (int x = 0; x < unicorn.getWidth(); x++)
    {
        for (int y = 0; y < unicorn.getHeight(); y++)
        {
            int counter = 0;
            ofColor color = uniPix.getColor(x, y);
            ofSetColor(color);
            ofDrawRectangle(x * gridSize, y * gridSize, gridSize, gridSize);
            
            
            // check state of pixels around
            for (int a = x - 1; a < x + 2; a++)
            {
                for (int b = y - 1; b < y + 2; b++)
                {
                    if (uniPix.getColor(a, b) == 255)
                    {
                        counter++; // count the live pixels around
                    }
                }
            }

            if (counter < 2 || counter > 4) // if isolated or overcrowded
                {
                    color = ofColor(0);
                }

            if (color == 0 && counter == 3) // if the center pixel is dead and there are 3 around it alive
            {
                color = ofColor(255);
                
            }

            uniPixN.setColor(x, y, color);
        }
    }
    
    uniPix = uniPixN;
}
