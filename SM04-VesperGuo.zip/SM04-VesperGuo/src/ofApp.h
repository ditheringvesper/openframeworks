#pragma once

#include "ofMain.h"
#include "ofxOsc.h"
#include "ofxKinect.h"
#include "ofxCv.h"
#include "ofxGui.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();
        void exit();

        void checkRecStat();

		void keyPressed(int key);
		void mousePressed(int x, int y, int button);

    
    
    std::string sendAddr;
    int sendPort;
    int recvPort;
    ofxOscSender sender;
    ofxOscReceiver receiver;
    int cursorX;
    int cursorY;
    bool recStat;
    bool preStat;
    std::string recString;
    float distMark;
    ofColor bangColor;
    ofColor colorStat;
    unsigned char* colorPtr;
    int colorV;
    int markX, markY, curX, curY;
    
    ofxKinect kinect;
    ofImage thresholdImg;
    
    ofxPanel guiPanel;
    ofxToggle recorder;
    ofParameter<float> distVal;
    ofParameter<float> nearVal;
    ofParameter<float> farVal;
    ofImage testImg;


};
