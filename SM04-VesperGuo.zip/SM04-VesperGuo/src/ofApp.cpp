#include "ofApp.h"
/* descriptoin:
    - set a spot on the image to set a depth detecting anchor by clicking
    - you can adjust the depth range of detection
    - when the 'recorder' toggle is on, the depth of the set anchor will trigger the recording & playback from MaxMsp
 */
void ofApp::setup(){
    ofSetWindowShape(640, 480);
    kinect.setRegistration(true);
    kinect.init();
    kinect.open();
    thresholdImg.allocate(320,240, OF_IMAGE_GRAYSCALE);

    // Set up the OSC sender.
    sendAddr = "127.0.0.1";
    sendPort = 8025;
    sender.setup(sendAddr, sendPort);
    recvPort = 8024;
    receiver.setup(recvPort);
    
    
//    distVal.set("distance threshold", 0.01f, 0.0f, 0.1f);
    nearVal.set("Near Threshold", 0.01f, 0.0f, 0.1f);
    farVal.set("Far Threshold", 0.05f, 0.0f, 0.1f);
    recStat = false;
    preStat = false;
    
    guiPanel.setup("room tone", "settings.json");
    guiPanel.add(recorder.setup("recorder toggle", recStat));
    guiPanel.add(nearVal);
    guiPanel.add(farVal);
}
void ofApp::exit()
{
  delete colorPtr;
}

//--------------------------------------------------------------
void ofApp::update(){

    colorStat = testImg.getColor(markX, markY);
    colorV =colorStat.getBrightness();

    while (receiver.hasWaitingMessages())
      {
        // get the next message
        ofxOscMessage msg;
        receiver.getNextMessage(msg);
        // connection check
        if (msg.getAddress() == "connected")
        {
            ofLogWarning(__FUNCTION__) << "connected";
        }
        else
        {
            ofLogWarning(__FUNCTION__) << "not connected";
        }
      }
    
}

//--------------------------------------------------------------

void ofApp::draw(){
    ofBackground(0);
    kinect.update();
    
    if (kinect.isFrameNew())
      {
        kinect.getDepthTexture().draw(ofGetWidth()/2, 0, 320,240);
          preStat = recStat;
          
          // detect the color of the threshold image && set a distance detection anchor
          if (colorV == 0){
              recStat = true;
          }
          else {
              recStat = false;
          }
                  
      // Threshold the depth.
      ofFloatPixels rawDepthPix = kinect.getRawDepthPixels();
      ofFloatPixels thresholdNear, thresholdFar, thresholdResult;
      ofxCv::threshold(rawDepthPix, thresholdNear, nearVal);
      ofxCv::threshold(rawDepthPix, thresholdFar, farVal, true);
      ofxCv::bitwise_and(thresholdNear, thresholdFar, thresholdResult);

      // Upload pixels to image.
      testImg.setFromPixels(thresholdResult);
          
      }

    testImg.draw(0,0);
    
    guiPanel.draw();
    
    if (recorder){
        checkRecStat();
    }
    ofDrawBitmapStringHighlight(recString, curX, curY);
    ofBeginShape();
    ofSetColor(bangColor);
    ofDrawCircle(curX-1, curY-1, 2);
    ofEndShape();
}


void ofApp::checkRecStat(){
    ofxOscMessage msg;
    if (recStat == true && preStat == false){
        msg.setAddress("1");
        bangColor = ofColor(255,0,0);
        recString = " recording";
        preStat = true;
    }
    else if (recStat == false && preStat == true){
        msg.setAddress("0");
        bangColor = ofColor(255,255,255);
        recString = " waiting";
        preStat = false;
    }
    sender.sendMessage(msg);

}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    if (!guiPanel.getShape().inside(x, y))
    {
        markX = ofMap(ofGetMouseX(), 0, 640, 0, 320);
        markY = ofMap(ofGetMouseY(), 0, 480, 0, 240);
        curX = ofGetMouseX();
        curY = ofGetMouseY();
    }
}

