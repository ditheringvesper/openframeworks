#pragma once

#include "ofMain.h"
#include "ofxOsc.h"
//#include "ofxKinect.h"
#include "ofxCv.h"
#include "ofxGui.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();
//        void exit();

        void checkRecStat();

		void keyPressed(int key);
		void mousePressed(int x, int y, int button);

    ofxPanel guiPanel;

    ofVideoGrabber grabber;
    ofVideoGrabber grabber2;

    ofImage backgroundImg;
    ofImage resultImg;
    
    cv::Mat grabberColorMat;
    cv::Mat grabberGrayMat;
    cv::Mat backgroundMat;
    cv::Mat resultMat;
    

    bool preRec;

/* 1st cam */
    bool recStat;
    bool preStat;
    
    ofParameter<bool> captureBackground;
    ofParameter<int> colorThreshold, ratioScale, blurVal;
    ofParameter<float> pixThreshRatio;
    
    
/* 2nd cam */
    ofxPanel guiPanel2;

    ofImage backgroundImg2;
    ofImage resultImg2;

    cv::Mat grabberColorMat2;
    cv::Mat grabberGrayMat2;
    cv::Mat backgroundMat2;
    cv::Mat resultMat2;
    
    ofParameter<bool> captureBackground2;
    ofParameter<int> colorThreshold2, ratioScale2, blurVal2;
    ofParameter<float> pixThreshRatio2;
    
    bool recStat2;
    bool preStat2;


    ofxToggle recorder;
    ofxLabel label;
    ofParameter<ofColor> recorderStatus;
    std::string recString;


    std::string sendAddr;
    int sendPort;
    int recvPort;
    ofxOscSender sender;
    ofxOscReceiver receiver;
    
    ofColor recColor;
    

//    ofxKinect kinect;
//    ofParameter<float> distVal;
//    ofParameter<float> nearVal;
//    ofParameter<float> farVal;
   
};
